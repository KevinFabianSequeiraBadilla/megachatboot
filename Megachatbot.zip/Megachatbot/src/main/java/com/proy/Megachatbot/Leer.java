
package com.proy.Megachatbot;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author Eduardo Fabian
 */

//El metodo llamado "leertxt" lee un archivo de texto y lo devuelve como una cadena.

// El método "leertxt" tiene un objeto "BufferedReader" para leer el archivo línea por línea-
//y por cada línea que se lee se va a agregar a una variable de cadena temporal.

public class Leer {
    File file = new File("datos.txt");
    public String leertxt(String direccion){
        String texto="";
        try {
            BufferedReader bf=new BufferedReader(new FileReader(direccion));
            String temporal="";
            String bfread;
            while ((bfread=bf.readLine()) !=null){
                temporal=temporal+bfread+"\r\n";
            }
            texto=temporal;
        } catch (Exception e) {
        }
        return texto;
    }
    //Aca estan los dos metodos "preguntanueva"  y "guardar". el primero lo que haces es meter las-
    // preguntas y respuestas en el txt y las modifica un poco ya que elimina las palabras mas comunes.
    
    //El segundo lo que hace es crear el txt si no existe y guarda las preguntas en el orden correspondiente-
    //( las nuevas al final de las qe ya tenia antes )
    
    public String preguntanueva(String pregunta,String respuesta){
        String nuevaPalabra="";
        String[] tupla3=pregunta.split(" ");
        for (int i=0;i<=tupla3.length-1;i++){
            if(i==tupla3.length-1){
                 nuevaPalabra=nuevaPalabra+tupla3[i]+"#"+tupla3[i]+"?"+"#"+respuesta;
            }else if (tupla3[i].equalsIgnoreCase("que")|| tupla3[i].equalsIgnoreCase("es")||tupla3[i].equalsIgnoreCase("un")||tupla3[i].equalsIgnoreCase("de")||tupla3[i].equalsIgnoreCase("hijo")){
                continue;
            }else {
            nuevaPalabra=nuevaPalabra+tupla3[i]+"#";}
        }
        System.out.println(nuevaPalabra);
        return nuevaPalabra;
    }
    public void guardar(String contenidoAnteriorTxt, String nuevapalabra){
        try {
		if(!file.exists()) {
				file.createNewFile();	
		}
		
		PrintWriter pw = new PrintWriter(file);
               // aca esta la parte de los write
                pw.append(contenidoAnteriorTxt + nuevapalabra);
		
                
		pw.close();
		System.out.println("Done");
		} catch (IOException e) {   
			e.printStackTrace();
		}
    }
    
}

// En el archivo de texto " datos " se puede eliminar tanto preguntas como resuestas ya guardadas 
// ( C:\Users\Edubg\Music\Megachatbot\Megachatbot )