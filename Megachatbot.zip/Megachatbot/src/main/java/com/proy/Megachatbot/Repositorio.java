/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.proy.Megachatbot;

/**
 *
 * @author Eduardo Fabian
 */

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import javax.swing.JOptionPane;


 // Ruta del archivo que contiene la base de datos de palabras o los textos que consultamos.
public class Repositorio extends FileController{
   
    private static final String REPO = "./datos.txt";
    
    // este es el lector utilizado en este caso
    private RandomAccessFile fileReader;
    
    public Repositorio()
    {
        // el argumento "REPO", es la constante que representa la ruta 
        // en el archivo de la base de datos
        super(REPO);
        try
        {
            
            // RandomAccessFile se utiliza para leer el archivo 
            // de datos de palabras. El objeto se crea en modo de solo lectura gracias a ("r").
            fileReader = new RandomAccessFile(file, "r");
            
            // Si el archivo no se puede encontrar va a tirar
            // un mensaje de error utilizando la clase JOptionPane
        }catch (FileNotFoundException e) {
             JOptionPane.showMessageDialog(
                null,
                "La base de datos de traduccion no fue encontrada",
                "Error Base Datos Traduccion",
                JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
        }
    }
    
    public String translate(String word)
    {
        String translation = "ok";
        String palabraGuardada="";
        String palabra=word;
        int contador=0, contador2=0;
 
        try
        {
            
            // "fileReader" es el que lee en el archivo
            String line = fileReader.readLine();
            boolean encontro=false;
            while(line != null && encontro != true)
            {
                
                // divide en una serie de palabras separadas por espacios en blanco
                String[] tupla = line.split("#");
                String[] tuplados =palabra.split(" ");

                for (int i=0;i<=tuplados.length-1;i++){ 
                for(int j=0;j<=tupla.length-1;j++){
                if (tuplados[i].equalsIgnoreCase(tupla[j]))
                {
                translation = tupla[tupla.length-1];
                contador++;
                }
                }
                }
               if (contador>=contador2){
                   contador2=contador;
                   palabraGuardada=translation;
               }
                contador=0;
                line = fileReader.readLine();
            }
           //  System.out.println("palbra acumulada : "+ palabraGuardada);
        }

        catch (IOException ioe)
        {
            JOptionPane.showMessageDialog(
                null,
                "Error al leer la base de datos de palabras",
                "Error Base Datos Traduccion",
                JOptionPane.ERROR_MESSAGE);
            ioe.printStackTrace();
        }

        finally
        {
            try
            {
                fileReader.close();
            }

            catch (IOException ioe)
            {
                JOptionPane.showMessageDialog(
                    null,
                    "Error al cerrar la base de datos de palabras",
                    "Error Base Datos Traduccion",
                    JOptionPane.ERROR_MESSAGE);
                ioe.printStackTrace();
            }
        }

        return palabraGuardada;
    }
  
    
}
